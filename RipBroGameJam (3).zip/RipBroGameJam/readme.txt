Post Processing Stack - Unity
https://assetstore.unity.com/packages/essentials/post-processing-stack-83912

MK Glow Free - Michael Kremmel
https://assetstore.unity.com/packages/vfx/shaders/fullscreen-camera-effects/mk-glow-free-28044

Right Arrow: Rotate Right
Space: Next Joint
Space + Right Arrow: Rotate Left


When RIP BRO appears, it's time to press space to restart the game